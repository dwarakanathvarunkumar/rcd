import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getRCD(): string {
    return 'Welcome to RCD !';
  }
}
