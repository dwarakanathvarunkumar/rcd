import { Entity,Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class chequestatusEntity {

    @PrimaryGeneratedColumn('uuid')
    id: number;

    @Column()
    name: string;

    @Column()
    code: string;

    @Column()
    Cheque_status: string;
}