export interface chequestatus {
    id: number;
    name: string;
    code: string;
    Cheque_status: string;
}