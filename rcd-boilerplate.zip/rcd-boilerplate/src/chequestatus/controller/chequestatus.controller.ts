import { Body, Controller, Get, Post } from '@nestjs/common';
import { Observable } from 'rxjs';
import { runInThisContext } from 'vm';
import { chequestatus } from '../models/chequestatus.interface';
import { chequestatusService } from '../service/chequestatus.service';

@Controller('chequestatus')
export class chequestatusController {

    constructor(private chequestatusService: chequestatusService) {}

    @Post()
    add(@Body() chequestatus: chequestatus): Observable<chequestatus> {
        return this.chequestatusService.add(chequestatus);
    }

    @Get()
    findAll(): Observable<chequestatus[]> {
        return this.chequestatusService.findAll();
    }
}
