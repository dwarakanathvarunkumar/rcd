import { Test, TestingModule } from '@nestjs/testing';
import { chequestatusService } from './chequestatus.service';

describe('chequestatusService', () => {
  let service: chequestatusService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [chequestatusService],
    }).compile();

    service = module.get<chequestatusService>(chequestatusService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
