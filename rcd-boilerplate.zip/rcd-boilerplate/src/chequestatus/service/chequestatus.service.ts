import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { from, Observable } from 'rxjs';
import { Repository } from 'typeorm';
import { chequestatusEntity } from '../models/chequestatus.entity';
import { chequestatus } from '../models/chequestatus.interface';

@Injectable()
export class chequestatusService {

    constructor(
        @InjectRepository(chequestatusEntity)
        private chequestatusRepository: Repository<chequestatusEntity>
    ) {}

    add(chequestatus: chequestatus): Observable<chequestatus> {
        return from(this.chequestatusRepository.save(chequestatus));
    }

    findAll(): Observable<chequestatus[]> {
        return from(this.chequestatusRepository.find());
    }

}
