import { Module } from '@nestjs/common';
import { chequestatusService } from './service/chequestatus.service';
import { chequestatusController } from './controller/chequestatus.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { chequestatusEntity } from './models/chequestatus.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([chequestatusEntity])
  ],
  providers: [chequestatusService],
  controllers: [chequestatusController]
})
export class ChequestatusModule {}
