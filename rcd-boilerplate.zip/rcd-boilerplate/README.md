Description

RCD Boilerplate repository with Nest framework.

You need

NPM
Node.js
NestJS
Docker

# run docker image from root directory of your project , using this command we can build the files for first time 

Start Commands for Docker
Build your image:
docker build <your path> -t <<user>/project-name>
$ docker-compose up --build


# run docker image from root directory of your project Start Commands for docker-compose file Builds, (re)creates, starts, and attaches to containers for a service.

$ docker-compose up 

# run docker image from root directory of your project 
$ docker-compose down



