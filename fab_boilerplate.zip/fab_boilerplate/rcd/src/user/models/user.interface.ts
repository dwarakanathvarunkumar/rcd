export interface UserI {
    id: number;
    name: string;
    code: string;
    cheque_status: string;
}