Description

RCD Boilerplate repository with Nest framework.

# run docker image from root directory of your project , using this command we can build the files for first time 
$ docker-compose up --build

# run docker image from root directory of your project
$ docker-compose up 

Installation
$ npm install

Running the app
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod

Test
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov

Connecting the database
